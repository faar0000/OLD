# Ejercicio 37
# Programa que lee una fecha como 12/03/2012 y devuelve 12 de marzo 2012

def imprimir_fecha(dd,mm,yyyy):
	xs = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre']
	print (dd,'de',xs[mm - 1],yyyy)

fecha = str(input("Porfavor, Ingrese su fecha según el formato (dia/mes/año): "))

if fecha[0] == str(0):
	dd = fecha[1]
else:
	dd = fecha[0:2]

if fecha[3] == str(0):
	mm = fecha[4]
else:
	mm = fecha[3:5]
yyyy = fecha[6:]

imprimir_fecha(int(dd),int(mm),int(yyyy))