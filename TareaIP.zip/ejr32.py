# Ejercicio 32
# Programa que analiza una lista de 20 elementos

def analisis_lista():
	contador = 0
	xs = []
	total = 0

	while contador < 20:
		msj1 = "Ingrese un número " + str((contador + 1)) + ":"
		n = int(input(msj1))
		xs.append(n)
		total += n 
		contador += 1
	promLista = total / (contador + 1)

	mayor = xs[0]
	for i in xs:
		if mayor < i:
			mayor = i
	
	menor = xs[0]
	for i in xs:
		if menor > i:
			menor = i

	print("(a) el menor número en la lista es ", menor)
	print("(b) el mayor número en la lista es ", mayor)
	print("(c) la suma total de los números en la lista es ", total)
	print("(d) el promedio de los números en la lista es ", round(promLista,2))

analisis_lista()