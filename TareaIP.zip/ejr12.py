# Ejercicio 12
# Cuantos insectos recogiste en la semana?

def recogeInsectos():
	total = 0

	contador = 0
	while (contador < 7):
		n = int(input("Cuantos insectos recogiste hoy? "))
		total += n
		contador += 1

	print ("Genial! Haz recogido", total, "insecto(s) en toda la semana")

recogeInsectos()