# Ejercicio 36
# Realizar un programa que muestre la suma de todos los digitos de un número ingresado
def suma_digitos(n):
	xs = list(str(n))
	suma = 0
	for i in xs:
		suma += int(i)

	return suma

n = int(input("Ingrese un número: "))

print("La suma de sus digitos es", suma_digitos(n))