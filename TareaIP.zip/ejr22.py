# Ejercicio 22
# contador de pares e impares, numeros aleatorios

import random

def contador_ParImpar(xs):
	contadorPar = 0
	contadorImpar = 0
	for i in xs:
		if i % 2 == 0:
			contadorPar += 1
		else:
			contadorImpar += 1
	print("Se han contado", contadorPar, "números pares y", contadorImpar, "números impares")

xs = []
for i in range(100):
	xs.append(random.randint(1,10))

print(xs)

contador_ParImpar(xs)