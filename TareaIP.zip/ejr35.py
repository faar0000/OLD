# Ejercico 35
# escribir un Programa que devuelva las iniciales de un nombre

def iniciales(nombre):
	ini = [] + [nombre[0]]

	for i in range(len(nombre)):
		if nombre[i] == ' ':
			ini.append(nombre[i + 1])
	for i in ini:
		print (i, end = "")
	print("")
	return ini


nombre = str(input("Ingrese un Nombre: "))

iniciales(nombre)