# Ejercicio N 03

def distancia(tiempo):
	# el ingreso anual es 23% de las ventas totales
	velocidad = 80
	return velocidad * tiempo

tiempo = int(input("Ingrese la cantidad de horas: "))

print("la distancia recorrida en", tiempo, "horas es", round(distancia(tiempo),2), "mts.")