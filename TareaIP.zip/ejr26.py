# Ejercicio 26
# Crear un archivo, abrirlo e imprimir numeros consecutivos del 1 al 100
file_object = open("number_list.txt", "w")

a = ""
for i in range(1,101):
	a += str(i) + " "

file_object.write(a)

file_object.close()