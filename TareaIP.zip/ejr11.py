# Ejercicio 11
# Programa que devuelve la suma de 1/30 + 2/29 + ... 30/1

def sumaFrac():
	suma = 0
	for i in range(1,31):
		suma += i/(31-i)
	return suma

print(round(sumaFrac(),5))