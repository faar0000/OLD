# Ejercicio 07

def puntosObtenidos(n):
	xs = [0,5,15,30,60]
	if n > (len(xs)-1):
		print("El cliente ha ganado", xs[len(xs)-1], "puntos.")
	elif 0 <= n <= (len(xs)-1):
		print ("El cliente ha ganado", xs[n], "puntos.")
	else:
		print("Critical Error")

n = int(input("Ingrese el número de libros comprados: "))

puntosObtenidos(n)