# Ejercicio 10
# Programa que retorna el conjunto de la serie 10, 20, 30, ... 1000
def serie10():
	return [i*10 for i in range(101)]

print(serie10())