# Ejercicio 20
# dibujo 'A' de #

def patitas(n):
	for i in range(n):
		print ("#"+(" " * i)+"#")

n = int(input("Ingrese el número de niveles de su triángulo: "))

patitas(n)