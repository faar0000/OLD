# Ejercicio30
# Generación de un número de Lotería

import random

def numLoteria():
	xs = list(range(7))
	for i in range(7):
		xs[i] = random.randint(0,9)
	return xs

print("Este es el número de Lotería generado:", numLoteria())