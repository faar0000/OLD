# Ejercicio 28
# Copiar los elementos de una lista a otra vacía

def buscar(x):
	for i in xs:
		if x == i:
			return True

	return False

xs = [1,2,3,4,5,6,7,8,9]
mensaje = "Ingrese el número que desea buscar en "+str(xs)+": "

n = int(input(mensaje))

if buscar(n) == True:
	print (n, "se encuentra en la lista")
else:
	print (n, "no se encuentra en la lista")