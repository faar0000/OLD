# Ejercicio 19
# dibujo triangulo invertido

def triangulo(n):
	for i in range(n,0,-1):
		print ("* " * i)

n = int(input("Ingrese el número de niveles de su triángulo: "))

triangulo(n)