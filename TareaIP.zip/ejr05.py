# Ejercicio 05

def romanos(n):
	xs = ['I','II','III','IV','V','VI','VII','VIII','IX','X']
	print (xs[n-1])

n = int(input("Ingrese un número: "))

if 0 < n < 11:
	romanos(n)
else:
	print("CRITICAL ERROR!")