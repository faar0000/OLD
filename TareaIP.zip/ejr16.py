# Ejercicio 16
# Programa que calcula la media de precipitaciones en un periodo de años

def precipitaciones(year):
	contYear = 1
	totalLluvia = 0
	while contYear <= year:
		print("Ingrese sus datos para el año", contYear)
		for i in range(1,13):
			print("Mes", i, ", ", end = " ")
			pulgLluvia = float(input("Cantidad de LLuvia: "))
			totalLluvia += pulgLluvia
		contYear += 1
	promMensualLluvia = totalLluvia / year / 12

	print("PROGRAMA FINALIZADO, Se han obtenido los siguientes resultados:")
	print("Total número de meses contabilizados: \t\t\t", year * 12)
	print("Total de pulgadas de lluvia registrado: \t", totalLluvia)
	print("Precipitación Media Mensual (PMM), en pulgadas:\t", round(promMensualLluvia,3))
# el programa debe mostrar el número de meses, el total de pulgadas de lluvia, y la precipitación media mensual
# para todo el periodo

años = int(input("Ingrese el número de años: "))

precipitaciones(años)
