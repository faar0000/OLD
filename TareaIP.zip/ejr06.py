#Ejercicio 06

def mezcla(color1,color2):
	coloresPrimarios = ['rojo','azul','amarillo'] # Base de colores primarios
	a = -1
	b = -2
	for i in range(3):
		if coloresPrimarios[i] == color1:
			a = i
		if coloresPrimarios[i] == color2:
			b = i
	# primero reconocer los colores en la base
	# luego verificar la combinación
	if a == b:
		print (coloresPrimarios[a])

	elif (a == 0 and b == 1) or (a == 1 and b == 0):
		print("púrpura")

	elif (a == 0 and b == 2) or (a == 2 and b == 0):
		print("naranja")

	elif (a == 1 and b == 2) or (a == 2 and b == 1):
		print("verde")

	else:
		print("CRITICAL ERROR !")

color1 = str(input("Ingrese el primer color: "))
color2 = str(input("Ingrese el segundo color: "))

mezcla(color1,color2)