# Ejercicio 04

def fechaMagica(dd,mm,yyyy):
	año = yyyy % 100
	if dd * mm == año:
		print ("Es una Fecha Mágica")
	else:
		print ("No es un Fecha Mágica")

dd = int(input("Ingrese un día: "))
mm = int(input("Ingrese un mes: "))
yyyy = int (input("Ingrese un año: "))

fechaMagica(dd,mm,yyyy)