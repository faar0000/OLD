# Ejercicio 25
# Juego de Piedra, Papel o Tijeras
import random

def juego():

	eleccion = str(input("Ingrese su elección (piedra/papel/tijeras): "))
	n = random.randint(1,3)
	xs = ['piedra','papel','tijeras']

	while True:
		eleccMaquina = n
		print("La Maquina escogió", xs[eleccMaquina - 1])

		eleccHumano = 0
		for i in range(3):
			if xs[i] == eleccion:
				eleccHumano = i + 1

		if eleccHumano == 1 and eleccMaquina == 3:
			print("La roca rompe a las tijeras !")
			print("Ud. ha ganado")
			break
		elif eleccMaquina == 1 and eleccHumano == 3:
			print("La roca rompe a las tijeras !")
			print("La maquina ha ganado ha ganado")
			break

		if eleccHumano == 3 and eleccMaquina == 2:
			print("Las tijeras cortan al papel !")
			print("Ud. ha ganado")
			break
		elif eleccMaquina == 3 and eleccHumano == 2:
			print("Las tijeras cortan al papel !")
			print("La maquina ha ganado ha ganado")
			break

		if eleccHumano == 2 and eleccMaquina == 1:
			print("El papel envuelve a la roca !")
			print("Ud. ha ganado")
			break
		elif eleccMaquina == 2 and eleccHumano == 1:
			print("El papel envuelve a la roca !")
			print("La maquina ha ganado ha ganado")
			break

		if eleccHumano == eleccMaquina:
			print("Ambos escogieron lo mismo, Juegue de nuevo")

		eleccion = str(input("Ingrese su elección (piedra/papel/tijeras): "))
		n = random.randint(1,3)

print("Bienvenido al Juego de Piedra, Papel o Tijeras")

juego()