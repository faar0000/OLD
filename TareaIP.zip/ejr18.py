# Ejercicio 18
# Sumatoria de varios números positivos

def sumatoria():
	sumatoria = 0
	n = int(input("Ingrese un número positivo (o número negativo para finalizar): "))
	while n >= 0:
		sumatoria += n
		n = int(input("Ingrese un número positivo (o número negativo para finalizar): "))
	print("Programa finalizado")
	print("La sumatoria de los números ingresados es:", sumatoria)
	return sumatoria
	
sumatoria()
