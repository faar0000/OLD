# Ejercicio 29
# Imprimir en forma matricial una lista de listas

def lista2dimensiones(xs):

	for i in xs:
		for j in i:
			print(j, end = " ")
		print(" ")

xs = [[1,2,3],[4,5,6],[7,8,9],[0,1,2]]

lista2dimensiones(xs)