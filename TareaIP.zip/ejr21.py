# Ejercicio 21
# caída libre

def failling_distrance(time):
	gravity = 9.8
	distance = gravity * time * time / 2
	return distance

print("Analisis de Caída Libre desde el reposo (g = 9,8 m/s)")
print("Tiempo(s)\tDistancia(m)")

for i in range(1,11):
	print(str(i) + " s\t\t" + str(round(failling_distrance(i),2)))