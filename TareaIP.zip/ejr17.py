# Ejercicio 17
# Ganancia en una determinada cantidad de días

def ganancia(dias):
	incremento = 2
	dinero = 0.01
	totalGanancia = 0
	print("Día(s)\tSueldo x Día")
	for i in range(1,dias + 1):
		print(i,"\tS/.", round(dinero,2))
		totalGanancia += dinero
		dinero *= incremento
	print("----------------------------")
	print("El total de dinero que Ud. ganará es S/.", round(totalGanancia,2))



n = int(input("Ingrese la el número de días que va a trabajar: "))
ganancia(n)