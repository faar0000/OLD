# Ejercicio N 02

def topos(n):
	# el ingreso anual es 23% de las ventas totales
	return n/3333

n = float(input("Ingrese la cantidad en m2: "))

print("Su equivalente en topos es:", round(topos(n),2))