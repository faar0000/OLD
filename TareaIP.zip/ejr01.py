# Ejercicio N 01

def ventasTotales(n):
	# el ingreso anual es 23% de las ventas totales
	return n*23/100

n = float(input("Ingrese el monto proyectado de ventas totales S/. "))

print("El ingreso proyectado para este año es S/.", round(ventasTotales(n),2))