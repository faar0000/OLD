# Ejercicio 08
# El programa muestra la cantidad de descuento y el importe total de la compra

def descuentos(cantidad): # cantidad = cantidad de paquetes comprados
	desc = [0.2,0.3,0.4,0.5] # tipos de descuentos
	precio = 99
	total = cantidad * precio

	# Menos de 10 libros, no hay desc
	if cantidad < 10:
		print("No hay descuento")
		print("Importe total de compra: $", total)

	cant = [10,20,50,100]

	for i in range(len(cant)-1):
		
		if cant[i] <= cantidad < cant[i+1]:
			print("Ud. tiene un descuento de", desc[i] * 100, "%")
			print("Importe de compra: $", total)
			print("Descuento: $", total * desc[i])
			total *= (1-desc[i])
			print("Importe de total de compra: $", total)
		
		if total != cantidad * precio:
			break

	if cantidad > 100:
		print("Ud. tiene un descuento de", desc[3] * 100, "%")
		print("Importe de compra: $", total)
		print("Descuento: $", total * desc[3])
		total *= (1-desc[3])
		print("Importe de total de compra: $", total)



cantidad = int(input("Ingrese la cantidad de paquete(es) que va a comprar: "))

descuentos(cantidad)
