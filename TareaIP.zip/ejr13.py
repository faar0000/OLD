# Ejercicio 13
# Cuantos calorías has quemado?

def quemaCalorias():
	minutos = [10,15,20,25,30,40,50,60]
	calorias = 3.9

	for i in minutos:
		print("Despúes de", i, "minutos, Ud. habrá quemado", i * calorias, "calorias!")

quemaCalorias()