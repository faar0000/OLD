# Ejercicio 24
# Cuenta de ahorros

def valorFuturoCuenta(dineroBase,intMensual,meses):
	interes = intMensual / 100
	dineroFuturo = dineroBase * ((1 + interes) ** meses)

	return dineroFuturo

dineroBase = float(input("Ingrese la Cantidad inicial de Dinero: "))
intMensual = int(input("Ingrese el Interés Mensual (%): "))
meses = int(input("Ingrese el número de meses: "))

print("El valor futuro de la cuenta es S/.", round(valorFuturoCuenta(dineroBase,intMensual,meses),2))