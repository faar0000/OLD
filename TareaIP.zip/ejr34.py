# Ejercicio 34
# Programa que devuelve las veces que un equipo gano la champions

# Primero debemos crear una base de datos, para lo que usaremos una lista

campeones = open("CampeonesChampions","r")
lineas = campeones.readlines()
campeones.close() # 0 1 4 5 8 9

i = 0
baseCampeones = []
while i < len(lineas):
	aux = []
	aux.append(lineas[i][0:7])
	cont1 = 0
	cont2 = 0
	for j in lineas[i + 1]:
		if j == ' ':
			cont1 += 1
		cont2 += 1
		if cont1 == 3:
			break
	cont1 = 0
	cont3 = 0
	for j in lineas[i + 1]:
		if j == '\t': # el python lee este tipo de caracter como uno solo
			cont1 += 1
		cont3 += 1
		if cont1 == 2:
			break

	aux.append(lineas[i+1][cont2:cont3-2])
	# print (aux) solo de verificación
	baseCampeones.append(aux)
	i += 4
# print (baseCampeones) solo de verificación

buscar = str(input("Ingrese el Equipo de su interes: "))
cont1 = 0
for i in baseCampeones:
	if i[1] == buscar:
		cont1 += 1

if cont1 == 0:
	print ("El Equipo que menciona no ha ganado ni un torneo, o escribió mal el nombre")
else:
	print("Su equipo ha ganado", cont1, "veces la Champions!")
