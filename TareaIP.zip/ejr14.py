# Ejercicio 14
# Total presupuestado

def gastos(totalPres):
	totalGastos = 0

	gastos = input("Ingrese sus gastos del mes (S para salir): S/.")
	if gastos == "S" or gastos == "s":
		print("No se ingresaron datos")
	else:
		while gastos != "S" and gastos != "s":
			totalGastos += int(gastos)
			gastos = input("Ingrese sus gastos del mes (S para salir): S/.")

		if totalPres < totalGastos:
			print("El total gastado esta por encima del Presupuestado")

		if totalPres == totalGastos:
			print("El total gastado es igual al Presupuestado")

		if totalPres > totalGastos:
			print("El total gastado esta por debajo del Presupuestado")

totalPres = int(input("Ingrese el Monto total Presupuestado: S/. "))

gastos(totalPres)