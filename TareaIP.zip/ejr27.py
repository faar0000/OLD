# Ejercicio 27
# Copiar los elementos de una lista a otra vacía

def copiar(xs,ys):
	for i in xs:
		ys.append(i)

	return ys

xs = list(range(100))
ys = []

print("Programa finalizado con exito! se ha copiado el contenido de", xs, "a", ys)
print("La copia es", copiar(xs,ys))