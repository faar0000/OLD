# Ejercicio 15
# Insertar un valor en la posicion adecuada de una lista

def insertar(xs,elemento):
	xs.append(elemento)

	for j in range(len(xs)-1):
		for i in range(len(xs)-1):
			if xs[i] >= xs[i+1]:
				a = xs[i]
				xs[i] = xs[i+1]
				xs[i+1] = a

	return xs

xs = [1,2,3,6,7]
print("Sea la lista", xs)
n = int(input("Ingrese un número: "))

print(insertar(xs,n))
	