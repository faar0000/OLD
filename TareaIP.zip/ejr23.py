# Ejercicio 23
# números primos hasta el 100

def Primos():
	n = 1

	while(n <= 100):
		divisores = 0
		for i in range(1,n+1):
			if n % i == 0:
				divisores += 1
		if divisores <= 2:
			print(n, end = " ")
		n += 1

	print(" ")

Primos()