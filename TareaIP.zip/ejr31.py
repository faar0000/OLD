# Ejercicio 31
# Análisis pluviométrico

def analisis_precipitacion():
	xs = [[0,'Enero'],[0,'Febrero'],[0,'Marzo'],[0,'Abril'],[0,'Mayo'],[0,'Junio'],[0,'Julio'],[0,'Agosto'],[0,'Septiembre'],[0,'Octubre'],[0,'Noviembre'],[0,'Diciembre']]
	contMeses = 0
	totalPrecipitacion = 0 # las tuplas no soportan asignación de valores

	while (contMeses < 12)	:
		msj1 = "Ingrese la Precipitacion Mensual para el Mes de " + xs[contMeses][1] + ": "
		precipitacionMensual = float(input(msj1))
		xs[contMeses][0] = precipitacionMensual
		totalPrecipitacion += precipitacionMensual
		contMeses += 1
	precipitacionMensualProm = totalPrecipitacion / 12

	mayor = xs[0][0]
	mayorMes = xs[0][1]
	for i in range(12):
		if mayor < xs[i][0]:
			mayor = xs[i][0]
			mayorMes = xs[i][1]

	menor = xs[0][0]
	menorMes = xs[0][1]
	for i in range(12):
		if menor > xs[i][0]:
			menor = xs[i][0]
			menorMes = xs[i][1]

	print("El total de Precipitación Anual fue de ", totalPrecipitacion)
	print("La precipitación acuosa mensual promedio fue de ", round(precipitacionMensualProm,2))
	print("Se registro la mayor precipitacion en el mes de", mayorMes, "con", mayor)
	print("Se registro la menor precipitacion en el mes de", menorMes, "con", menor)

analisis_precipitacion()