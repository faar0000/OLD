#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <time.h>
#include <SDL/SDL_IMAGE.h>
#include <SDL/SDL_MIXER.h>
#include <iostream>

using namespace std;

SDL_Surface * screen;
SDL_Surface * surface;
SDL_Surface * imagen;
SDL_Surface * imagen2;
SDL_Surface * imagen3;
SDL_Surface * imagen4;
SDL_Surface * roca;
SDL_Surface * fantasma;
SDL_Surface * comida;
SDL_Event tecla;
SDL_Rect dest;
SDL_Rect dest1;
SDL_Rect dest2;
SDL_Rect dest3;



void iniciar_sdl(){
    SDL_Init(SDL_INIT_VIDEO| SDL_INIT_AUDIO);
    freopen ("CON", "w", stdout); // Redirige stdout
    freopen ("CON", "w", stderr); // Redirige stderr
}

void establecer_modo_de_video(){
    screen = SDL_SetVideoMode(800,600,32,SDL_SWSURFACE);

}

void choque(){
    if (dest.x == dest1.x and dest.y == dest1.y){
        exit(1);
    }

}

void cargar_datos(){
    imagen = IMG_Load("pacman1.bmp");
        dest.x = 350;
        dest.y = 250;
        dest.w = imagen->w;
        dest.h = imagen->h;
    imagen2= IMG_Load("pacman2.bmp");
    imagen3= IMG_Load("pacman3.bmp");
    imagen4= IMG_Load("pacman4.bmp");
    comida=IMG_Load("comida.bmp");
        dest3.x = 50;
        dest3.y = 50;
    roca = IMG_Load("roca.bmp");
       // dest1.x = 0;
        //dest1.y = 0;
    fantasma = IMG_Load("enemigo.bmp");
        dest2.x = 200;
        dest2.y = 200;

    Mix_Music*sonido;
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT,2,1024)){

    }
    sonido = Mix_LoadMUS("sonido.mp3");
    Mix_PlayMusic(sonido,-1);

    int r,t;
    for (r=1;r<10;r++){
        SDL_BlitSurface(comida, NULL,screen,&dest3);
        dest3.y=dest3.y+100;
        for (t=r;t<10;t++){
            SDL_BlitSurface(comida, NULL,screen,&dest3);
            dest3.x= dest3.x +100;
            }

        }
}


int main(int argc, char *argv[]){


    cargar_datos();
     iniciar_sdl();
    establecer_modo_de_video();
    choque();
    SDL_WM_SetCaption("Pacman by Alejandro", NULL);
    if (dest.x==dest1.x and dest.y==dest1.y){
        exit(0);
    }

    while(true){
        atexit(SDL_Quit);


        SDL_FillRect(screen,0,SDL_MapRGB(screen ->format,0,0,0));

        if (tecla.key.keysym.sym == SDLK_UP){
            SDL_BlitSurface(imagen3, NULL, screen, &dest);
        }
        else if (tecla.key.keysym.sym == SDLK_DOWN){
            SDL_BlitSurface(imagen4, NULL, screen, &dest);
        }
        else if (tecla.key.keysym.sym == SDLK_LEFT){
            SDL_BlitSurface(imagen, NULL, screen, &dest);
        }
        else if (tecla.key.keysym.sym == SDLK_RIGHT){
            SDL_BlitSurface(imagen2, NULL, screen, &dest);
        }



 //           SDL_BlitSurface(imagen, NULL, screen, &dest);
 //           SDL_BlitSurface(imagen2, NULL, screen, &dest);
 //           SDL_BlitSurface(imagen3, NULL, screen, &dest);
 //           SDL_BlitSurface(imagen4, NULL, screen, &dest);

        SDL_BlitSurface(fantasma, NULL,screen,&dest2);

        int r,t;
        for (r=1;r<10;r++){
          SDL_BlitSurface(comida, NULL,screen,&dest3);
          dest3.y=dest3.y+100;
            for (t=r;t<10;t++){
                SDL_BlitSurface(comida, NULL,screen,&dest3);
                dest3.x= dest3.x +100;
            }

        }
        int e=32;
        for (int i=0;i<26;i++){
            SDL_BlitSurface(roca, NULL,screen,&dest1);
            dest1.x = e*i;
            dest1.y = 0;
        }

        for (int i=0;i<26;i++){
            SDL_BlitSurface(roca, NULL,screen,&dest1);
            dest1.x = e*i;
            dest1.y = 568;
        }


        for (int i=0;i<19;i++){
            dest1.x = 0;
            dest1.y = e*i;
            SDL_BlitSurface(roca, NULL,screen,&dest1);
        }


        for (int i=0;i<18;i++){
            dest1.x = 768;
            dest1.y = e*i;SDL_SetColorKey(imagen, SDL_SRCCOLORKEY|SDL_RLEACCEL, SDL_MapRGB(imagen->format,255,0,255));
            SDL_BlitSurface(roca, NULL,screen,&dest1);
        }



        SDL_SetColorKey(imagen, SDL_SRCCOLORKEY|SDL_RLEACCEL, SDL_MapRGB(imagen->format,255,0,255));
        SDL_SetColorKey(imagen2, SDL_SRCCOLORKEY|SDL_RLEACCEL, SDL_MapRGB(imagen2->format,255,0,255));
        SDL_SetColorKey(imagen3, SDL_SRCCOLORKEY|SDL_RLEACCEL, SDL_MapRGB(imagen3->format,255,0,255));
        SDL_SetColorKey(imagen4, SDL_SRCCOLORKEY|SDL_RLEACCEL, SDL_MapRGB(imagen4->format,255,0,255));
        SDL_SetColorKey(fantasma, SDL_SRCCOLORKEY|SDL_RLEACCEL, SDL_MapRGB(fantasma->format,255,0,255));
        SDL_SetColorKey(comida, SDL_SRCCOLORKEY|SDL_RLEACCEL, SDL_MapRGB(comida->format,255,0,255));

        SDL_Flip(screen);

        while (SDL_PollEvent(&tecla)){
            if (tecla.type == SDL_QUIT){ exit(0);}
            if (tecla.type == SDL_KEYDOWN){
                if (tecla.key.keysym.sym == SDLK_ESCAPE){
                    exit(0);
                }
                if (tecla.key.keysym.sym == SDLK_UP){
                        if(dest.y>25)
                        {
                        dest.y -= 15;
                        }
                }
                 if (tecla.key.keysym.sym == SDLK_DOWN){
                    dest.y += 15;
                }
                if (tecla.key.keysym.sym == SDLK_LEFT){
                    dest.x -= 15;
                }
                if (tecla.key.keysym.sym == SDLK_RIGHT){
                    dest.x += 15;
                }
            }
        }

    }


    SDL_FreeSurface(imagen);
    return 0;

}
