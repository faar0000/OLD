#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWebEngineView>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
//#include <QGraphicsView>
class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    void cRect()
    {
        //scene= new QGraphicsScene();
        QGraphicsRectItem *rect = new QGraphicsRectItem();
        rect->setRect(0,0,100,100);

        //scene->addItem(rect);
        //view= new QGraphicsView(scene);
        //view->show();
    }
private:
    QWebEngineView *m_view;
    QGraphicsScene *scene;
    //QGraphicsView *view;
};

#endif // MAINWINDOW_H
