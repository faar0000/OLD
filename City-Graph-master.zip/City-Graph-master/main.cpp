#include <graph.h>
#include <graph.cpp>
#include <string>
#include "mainwindow.h"
#include <QApplication>
#include <QtXml/qdom.h>
#include <QtCore>
#include <fstream>
#include "dijkstra.h"
#define INFINITY (MAX_INT-1)
using namespace std;
void saveData();
void listElements(QDomElement root,QString tagname,QString attribute,QString attribute2)
{
    QDomNodeList items=root.elementsByTagName(tagname);
    //QDebug() << "total items" << items.count();
    Graph<string,int> g;
    QString s;
    QString s1;
    string h;
    string f;
    string sum=",";
    for (int i = 0; i < items.count(); ++i) {
        QDomNode itemnode=items.at(i);
        if(itemnode.isElement())
        {
            QDomElement itemele=itemnode.toElement();
            s=itemele.attribute(attribute);

            s1=itemele.attribute(attribute2);
            h=s.toStdString();
            f=s1.toStdString();
            g.insertVertex(h+sum+f);
            //g.insertVertex(h);
            qDebug() << s <<"<->" << s1 ;
            //cout << h << "--->" <<i << endl;
            h=s.toStdString();
            g.insertVertex(h);

            //qDebug() << s << i ;
            //cout << h << "--->" <<i << endl;
        }
    }

}

void parcing()
{
    QDomDocument document;

    QFile file("/home/alejandro/Escritorio/City-Graph/OsmData/map.osm");
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        qDebug() << "falied load file";
    }
    else
    {
        if(!document.setContent(&file))
        {
            qDebug() << "falied load file";
        }
        file.close();
    }
    QDomElement root=document.firstChildElement();

    listElements(root,"way","lat","lon");
}
void testGraph()
{
    Graph<string,int> g;
    //g.proof("hello");
    g.insertVertex("A");
    g.insertVertex("B");
    g.insertVertex("C");
    g.insertVertex("D");
    g.insertVertex("E");
    g.insertVertex("Z");
    g.insertEdge(g.findVertex("A"),g.findVertex("B"),3);
    g.insertEdge(g.findVertex("A"),g.findVertex("C"),4);
    g.insertEdge(g.findVertex("C"),g.findVertex("E"),1);
    g.insertEdge(g.findVertex("B"),g.findVertex("E"),5);
    g.insertEdge(g.findVertex("B"),g.findVertex("D"),6);
    g.insertEdge(g.findVertex("E"),g.findVertex("D"),2);
    g.insertEdge(g.findVertex("D"),g.findVertex("Z"),7);
    g.insertEdge(g.findVertex("E"),g.findVertex("Z"),12);
    //g.adjacencyList();
    g.dijkstra(g.findVertex("A"),g.findVertex("Z"));
}

void testDijkstra()
{
    int v=9;
    Graphs g(v);
    g.addEdge(0, 1, 4);
    g.addEdge(0, 7, 8);
    g.addEdge(1, 2, 8);
    g.addEdge(1, 7, 11);
    g.addEdge(2, 3, 7);
    g.addEdge(2, 8, 2);
    g.addEdge(2, 5, 4);
    g.addEdge(3, 4, 9);
    g.addEdge(3, 5, 14);
    g.addEdge(4, 5, 10);
    g.addEdge(5, 6, 2);
    g.addEdge(6, 7, 1);
    g.addEdge(6, 8, 6);
    g.addEdge(7, 8, 7);
    g.shortestPath(0);
}
int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QApplication app(argc, argv);
    MainWindow mainWindow;
    mainWindow.cRect();
    mainWindow.show();
    return app.exec();
    //testGraph();
    //parcing();
    //testDijkstra();
    //Graph<string,int> c;
    //c.insertVertex("data");
    //c.print();

}
